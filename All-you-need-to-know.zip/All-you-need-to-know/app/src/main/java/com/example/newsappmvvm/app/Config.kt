package com.example.newsappmvvm.app

class Config {
    companion object{
        const val BASE_URL = "https://newsapi.org/v2/"
        const val API_KEY = "a1c63f6fa6a645088799c895f54f5ed6"
    }
}