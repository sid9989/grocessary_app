package com.example.grocessaryapp.app

class Config {
    companion object{
        const val BASE_URL = "http://apolis-grocery.herokuapp.com/api/"
        const val IMAGE_URL = "http://rjtmobile.com/grocery/images/"
        const val DATABASE_NAME = "mydb"
        const val DATABASE_VERSION = 1
    }
}

