package com.example.myapplication.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.myapplication.R
import com.example.myapplication.database.DbHelper
import com.example.myapplication.models.Tasks
import kotlinx.android.synthetic.main.activity_add_task.*

class AddTaskActivity : AppCompatActivity() {

    lateinit var dbHelper: DbHelper
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_task)

        dbHelper = DbHelper(this)

        init()


    }
    private fun init(){
        button_save.setOnClickListener{

            var title=edit_text_title.text.toString()
            var desc=edit_text_desc.text.toString()

            var task= Tasks(title = title,desc = desc)

            dbHelper.addTask(task)

        }


    }
}