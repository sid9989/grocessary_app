package com.example.myapplication.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.R
import com.example.myapplication.adapters.TaskAdapter
import com.example.myapplication.database.DbHelper
import com.example.myapplication.models.Tasks
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    lateinit var dbHelper: DbHelper
    lateinit var taskAdapter: TaskAdapter

    var mList: ArrayList<Tasks> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbHelper = DbHelper(this)
        taskAdapter = TaskAdapter(this)

        init()
    }

    private fun init() {

        button_add_task.setOnClickListener {
            startActivity(Intent(this, AddTaskActivity::class.java))
        }

        mList = dbHelper.getAllTask()
        taskAdapter.setData(mList)
        recycler_view.adapter = taskAdapter
        recycler_view.layoutManager = LinearLayoutManager(this)
    }

    override fun onRestart() {
        super.onRestart()
        mList = dbHelper.getAllTask()
        taskAdapter.setData(mList)
    }
}