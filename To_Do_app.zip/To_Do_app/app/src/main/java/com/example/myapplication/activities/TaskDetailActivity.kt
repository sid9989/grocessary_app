package com.example.myapplication.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.myapplication.R
import com.example.myapplication.database.DbHelper
import com.example.myapplication.models.Tasks
import kotlinx.android.synthetic.main.activity_task_detail.*



class TaskDetailActivity : AppCompatActivity() {

    var task:Tasks?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_task_detail)


        init()
    }

    private fun init(){

        task=intent.getSerializableExtra(Tasks.KEY_TASK) as Tasks
        text_view_title.text=task?.title
        text_view_desc.text=task?.desc


    }
}