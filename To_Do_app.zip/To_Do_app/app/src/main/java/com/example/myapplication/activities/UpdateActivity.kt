package com.example.myapplication.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.myapplication.R
import com.example.myapplication.database.DbHelper
import com.example.myapplication.models.Tasks
import kotlinx.android.synthetic.main.activity_update.*

class UpdateActivity : AppCompatActivity() {

    var task: Tasks?=null
    lateinit var dbHelper: DbHelper
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update)

        dbHelper = DbHelper(this)

        init()
    }

    private fun init(){
        task=intent.getSerializableExtra(Tasks.KEY_TASK) as Tasks
        text_view_title.text=task?.title
        var id=task?.id

        button_update.setOnClickListener{
        var desc=edit_text_desc.text.toString()
        var title=text_view_title.text.toString()

        var task1= Tasks(id=id,title = title,desc = desc)

        dbHelper.updateTask(task1)}


    }
}