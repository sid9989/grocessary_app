package com.example.myapplication.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R
import com.example.myapplication.activities.TaskDetailActivity
import com.example.myapplication.activities.UpdateActivity
import com.example.myapplication.database.DbHelper
import com.example.myapplication.models.Tasks
import kotlinx.android.synthetic.main.row_product_adapter.view.*

class TaskAdapter(var mContext: Context): RecyclerView.Adapter<TaskAdapter.ViewHolder>() {

    lateinit var dbHelper: DbHelper
    var mList: ArrayList<Tasks> = ArrayList()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(mContext).inflate(R.layout.row_product_adapter, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        var product = mList[position]
        holder.bind(product)
    }

    override fun getItemCount(): Int {
        return mList.size
    }
    fun setData(list: ArrayList<Tasks>) {
        mList = list
        notifyDataSetChanged()
    }

    inner class ViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){

        fun bind(task:Tasks){
            itemView.text_view_title.text=task.title


            itemView.setOnClickListener {
                var intent = Intent(mContext, TaskDetailActivity::class.java)
                intent.putExtra(Tasks.KEY_TASK,task)
                mContext.startActivity(intent)

            }

            itemView.image_view_edit.setOnClickListener {
                var intent = Intent(mContext, UpdateActivity::class.java)
                intent.putExtra(Tasks.KEY_TASK,task)
                mContext.startActivity(intent)


            }

            itemView.image_view_delete.setOnClickListener {

                dbHelper = DbHelper(mContext)
                dbHelper.deleteTask(task.id!!)
                mList = dbHelper.getAllTask()
                notifyDataSetChanged()
            }
        }
    }


}