package com.example.myapplication.database

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.myapplication.models.Tasks

class DbHelper(var mContext: Context) :
    SQLiteOpenHelper(mContext, DATABASE_NAME, null, DATABASE_VERSION) {


    var db = writableDatabase
    companion object {
        const val DATABASE_NAME = "mydb"
        const val DATABASE_VERSION = 1
        const val TABLE_NAME = "task"
        const val COLUMN_ID = "id"
        const val COLUMN_TITLE = "title"
        const val COLUMN_DESCRIPTION = "description"
    }


    override fun onCreate(db: SQLiteDatabase?) {
        val createTable =
            "create table $TABLE_NAME ($COLUMN_ID INTEGER PRIMARY KEY, AUTO_INCREMENT, $COLUMN_TITLE CHAR(50), $COLUMN_DESCRIPTION CHAR(200))"
        db?.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
        val dropTable = "drop table $TABLE_NAME"
        db?.execSQL(dropTable)
        onCreate(db)
    }
    fun addTask(task: Tasks) {
        var contentValues = ContentValues()
        contentValues.put(COLUMN_TITLE, task.title)
        contentValues.put(COLUMN_DESCRIPTION, task.desc)
        db.insert(TABLE_NAME, null, contentValues)
    }

    fun updateTask(task: Tasks) {
        var contentValues = ContentValues()
        contentValues.put(COLUMN_TITLE, task.title)
        contentValues.put(COLUMN_DESCRIPTION, task.desc)
        var whereClause = "$COLUMN_ID = ?"
        var whereArgs = arrayOf(task.id.toString())
        db.update(TABLE_NAME, contentValues, whereClause, whereArgs)
    }

    fun deleteTask(id: Int) {
        var whereClause = "$COLUMN_ID = ?"
        var whereArgs = arrayOf(id.toString())
        db.delete(TABLE_NAME, whereClause, whereArgs)
    }

    @SuppressLint("Range")
    fun getAllTask(): ArrayList<Tasks> {
        var tasks: ArrayList<Tasks> = ArrayList()
        var columns = arrayOf(
            COLUMN_ID,
            COLUMN_TITLE,
            COLUMN_DESCRIPTION
        )
        var cursor = db.query(TABLE_NAME, columns, null, null, null, null, null)
        if (cursor != null && cursor.moveToFirst()) {
            do {
                var id = cursor.getInt(cursor.getColumnIndex(COLUMN_ID))
                var title = cursor.getString(cursor.getColumnIndex(COLUMN_TITLE))
                var description = cursor.getString(cursor.getColumnIndex(COLUMN_DESCRIPTION))
                var task = Tasks(id, title, description)
                tasks.add(task)
            } while (cursor.moveToNext())
        }
        return tasks
    }

    @SuppressLint("Range")
    fun getTaskById(id: Int): Tasks? {
        var task: Tasks? = null
        var query = "select * from $TABLE_NAME where $COLUMN_ID = ?"
        var cursor = db.rawQuery(query, arrayOf(id.toString()))
        if (cursor != null) {
            var id = cursor.getInt(cursor.getColumnIndex(COLUMN_ID))
            var title = cursor.getString(cursor.getColumnIndex(COLUMN_TITLE))
            var description = cursor.getString(cursor.getColumnIndex(COLUMN_DESCRIPTION))
            task = Tasks(id, title, description)
        }
        return task
    }

}