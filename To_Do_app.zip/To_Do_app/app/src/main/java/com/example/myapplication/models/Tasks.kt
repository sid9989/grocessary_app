package com.example.myapplication.models

import java.io.Serializable

data class Tasks(
    var id:Int?=null,
    var title: String,
    var desc: String
): Serializable{
    companion object{
        const val KEY_TASK = "task"
    }
}


